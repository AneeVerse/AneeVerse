<tbody {{ $attributes->merge(['class' => 'bg-white dark:bg-gray-900 dark:text-gray-300 dark:border-gray-800']) }}>
    {{ $slot }}
</tbody>