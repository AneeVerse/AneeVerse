<thead {{ $attributes->merge(['class' => 'bg-gray-50 dark:border-gray-800 dark:bg-gray-900 dark:text-gray-300']) }}>
    {{ $slot }}
</thead>