<td {{ $attributes->merge(['scope' => 'row', 'class' => 'whitespace-nowrap px-6 py-4']) }}>
    {{ $slot }}
</td>
    