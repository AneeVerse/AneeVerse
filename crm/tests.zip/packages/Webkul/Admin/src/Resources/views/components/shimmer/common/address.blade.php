<div class="flex gap-4">
    <div class="w-full">
        <div class="shimmer w-50% h-56"></div>
    </div>

    <div class="grid w-full gap-3">
        <div class="shimmer w-50% h-10"></div>

        <div class="shimmer w-50% h-10"></div>

        <div class="shimmer w-50% h-10"></div>
        
        <div class="shimmer w-50% h-10"></div>
    </div>
</div>