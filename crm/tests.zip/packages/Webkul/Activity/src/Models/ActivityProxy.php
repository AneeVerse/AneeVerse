<?php

namespace Webkul\Activity\Models;

use Konekt\Concord\Proxies\ModelProxy;

class ActivityProxy extends ModelProxy {}
