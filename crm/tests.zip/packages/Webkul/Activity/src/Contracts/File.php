<?php

namespace Webkul\Activity\Contracts;

interface File {}
