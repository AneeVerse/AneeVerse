<?php

test('check basic unit test', function () {
    $this->assertTrue(true);

    expect(true)->toBeTrue();
});
